# róka és libák - játék FreePascal-ban
unzip: minden file azonos könyvtárban legyen.
