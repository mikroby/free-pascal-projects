# életjáték szimuláció freePascal-ban
unzip: minden file azonos könyvtárban legyen.
