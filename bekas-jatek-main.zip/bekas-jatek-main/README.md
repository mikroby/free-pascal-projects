# békás-játék freePascal-ban
unzip: minden file azonos könyvtárban legyen.
